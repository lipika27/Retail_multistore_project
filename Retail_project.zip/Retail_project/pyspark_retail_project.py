# Databricks notebook source
dbutils.widgets.dropdown("time_period",'weekly',['weekly','monthly'])

# COMMAND ----------

from datetime import date,timedelta,datetime
from pyspark.sql.functions import * 

time_period= dbutils.widgets.get("time_period")
print(time_period)
today = date.today()

if time_period=='weekly':
    start_date=today-timedelta(days=today.weekday(),weeks=1)-timedelta(days=1)
    end_date=start_date+timedelta(days=6)

else:
    first=today.replace(day=1)
    end_date=first-timedelta(days=1)
    start_date=first-timedelta(days=end_date.day)

print(start_date,end_date)

# COMMAND ----------

df=spark.read.csv("/FileStore/tables/superstore-1.csv",header=True,inferSchema=True)
display(df)

# COMMAND ----------

# DBTITLE 1,temp table
df.createOrReplaceTempView("sample")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from samples

# COMMAND ----------

display(spark.sql(f"""select count(distinct customer_id) from sample where Order_Date between 'start_date' and 'end_date' """))

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(distinct order_id) from sample

# COMMAND ----------

display(spark.sql(f"""select count(distinct order_id) from sample where order_date between 'start_date' and 'end_date' """))

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(sales) total_sales ,sum(profit) total_profit from sample

# COMMAND ----------

# DBTITLE 1,top sale by country
# MAGIC %sql
# MAGIC select sum(sales),country,region from sample group by country,region order by 1 desc

# COMMAND ----------

# DBTITLE 1,top sales catagory product
# MAGIC %sql
# MAGIC select sum(sales) tsales,category from sample group by 2 order by 1 desc 

# COMMAND ----------

# DBTITLE 1,top 10 sales sub category
# MAGIC %sql
# MAGIC select sum(sales) tsales,sub_category from sample group by 2 order by 1 desc limit 10

# COMMAND ----------

# DBTITLE 1,most order quantitiy product
# MAGIC %sql
# MAGIC select sum(quantity),product_name from sample group by product_name order by 1 desc

# COMMAND ----------

# DBTITLE 1,top customer based on their order
# MAGIC %sql
# MAGIC select sum(sales),customer_name,city from sample group by customer_name,city 
# MAGIC order by sum(sales) desc limit 1